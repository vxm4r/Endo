import { downloadContentFromMessage } from "@whiskeysockets/baileys";

export default {
    name: "كشف",
    description: "كشف رسائل المشاهدة لمرة واحدة (View Once)",
    async run({ sock, message, reply }) {
        // 1. الحصول على الرسالة التي تم الرد عليها
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted) {
            return reply("⚠️ يرجى الرد على رسالة (عرض مرة واحدة) لكشفها.");
        }

        // 2. دالة محسنة لاستخراج محتوى الوسائط الفعلي
        function getMediaDetails(msg) {
            // فحص الطبقات المتعددة لرسائل View Once (V1 & V2)
            const viewOnce = msg?.viewOnceMessage?.message || 
                             msg?.viewOnceMessageV2?.message || 
                             msg?.viewOnceMessageV2Extension?.message || 
                             msg;

            if (viewOnce?.imageMessage) return { type: "image", data: viewOnce.imageMessage };
            if (viewOnce?.videoMessage) return { type: "video", data: viewOnce.videoMessage };
            if (viewOnce?.audioMessage) return { type: "audio", data: viewOnce.audioMessage };
            
            return null;
        }

        const media = getMediaDetails(quoted);

        if (!media || !media.data) {
            return reply("❌ لم يتم العثور على وسائط قابلة للكشف في هذه الرسالة.");
        }

        // 3. التحقق من وجود مفتاح التشفير لتجنب خطأ "empty media key"
        if (!media.data.mediaKey) {
            return reply("❌ خطأ: مفتاح الوسائط مفقود. قد تكون الرسالة قديمة جداً.");
        }

        try {
            // 4. تحميل الوسائط
            const stream = await downloadContentFromMessage(media.data, media.type);
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            // 5. إرسال الوسائط المستخرجة
            const caption = "✅ تم كشف المحتوى بنجاح";
            const jid = message.key.remoteJid;

            if (media.type === "image") {
                return await sock.sendMessage(jid, { image: buffer, caption }, { quoted: message });
            } 
            if (media.type === "video") {
                return await sock.sendMessage(jid, { video: buffer, caption }, { quoted: message });
            }
            if (media.type === "audio") {
                return await sock.sendMessage(jid, { audio: buffer, mimetype: "audio/mp4", ptt: false }, { quoted: message });
            }

        } catch (error) {
            console.error("Kashf Error:", error);
            return reply("❌ فشل كشف الوسائط. تأكد من تحديث مكتبة Baileys.");
        }
    }
};
