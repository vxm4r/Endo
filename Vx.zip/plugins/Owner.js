import fs from 'fs';

export default {
    name: "المطور",
    description: "للتواصل مع فريق 𝐕𝐗 BOT Development Team والدعم التقني.",
    category: "general",
    aliases: ["owner", "dev", "vxdev"], // إعادة Alias مناسب

    async run({ bot, message, react }) {
        const jid = message.key.remoteJid;

        // 🌟 1. البدء والتفاعل الأولي
        await react('👑'); // تفاعل ملكي (Owner)

        // --- الخطوة 2: التحقق من الموارد (ملف العرض) ---
        const gifPath = './media/solo_dev.mp4';
        if (!fs.existsSync(gifPath)) {
            console.error(`[المطور] ⚠️ خطأ فادح: ملف العرض غير موجود في المسار: ${gifPath}`);
            await react('❌');
            return "عذرًا. فشل تحميل الموارد البصرية. يرجى مراجعة مسار الملف.";
        }

        // --- الخطوة 3: إرسال العرض البصري (GIF/MP4) مع رسالة فخمة ---
        const gifBuffer = fs.readFileSync(gifPath);
        
        // رسالة تعليق (Caption) فخمة ومصقولة
        const elegantCaption = 
`*✦ ━━━━━━『 𝐕𝐗 𝐁𝐎𝐓 』━━━━━━ ✦*

*👑 مطور النظام (System Owner) 👑*

_هدفنا هو تقديم أفضل تجربة. يسعدنا تواصلكم معنا للدعم التقني والاقتراحات._

👇 *معلومات الاتصال:*`;

        await bot.sendMessage(jid, {
            video: gifBuffer,
            mimetype: 'video/mp4',
            gifPlayback: true,
            caption: elegantCaption, // استخدام التعليق الأنيق
        }, { quoted: message });

        // --- الخطوة 4: تعريف وتنسيق جهات الاتصال (vCard) ---
        const developerName = "𝐕𝐗𝟒𝐌𝐑 - System Architect";
        const developerNumber = "+212717127742";
        
        const developers = [
            {
                displayName: developerName,
                // تنسيق VCard احترافي ومفصل
                vcard: 
`BEGIN:VCARD
VERSION:3.0
FN:${developerName}
TEL;type=CELL;waid=212717127742:${developerNumber}
ORG:VX BOT Development Team
TITLE:Lead Developer | System Architect
NOTE:للاستفسارات، الدعم الفني، أو تقارير الأخطاء.
URL:https://wa.me/212717127742
END:VCARD`
            }
        ];

        // --- الخطوة 5: إرسال جهات الاتصال بطريقة مرتبة ---
        await bot.sendMessage(jid, {
            contacts: {
                // اسم عرض جذاب للمجموعة
                displayName: `[👑] 𝐕𝐗 𝐁𝐎𝐓 | المطور الرئيسي`,
                contacts: developers
            }
        }, { quoted: message });
        
        // ✅ 6. التفاعل بالنجاح
        await react('✅'); 
    }
};
