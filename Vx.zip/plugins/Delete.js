import fs from "fs";
import path from "path";

export default {
    name: "حذف",
    developer: true,
    async run({ reply, args }) {
        try {
            const cmdName = args[0];
            if (!cmdName) return reply("❌ حدد اسم الأمر الذي تريد حذفه.");

            // مسار الملف في مجلد plugins
            const filePath = path.join("./plugins", `${cmdName}.js`);
            if (!fs.existsSync(filePath)) return reply("❌ هذا الأمر غير موجود.");

            fs.unlinkSync(filePath);
            reply(`🗑️ تم حذف الأمر: .${cmdName}`);
        } catch (err) {
            reply("❌ خطأ: " + err.message);
        }
    }
};