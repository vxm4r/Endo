// ملف: plugins/اخرج.js

export default {
    name: "اخرج",
    aliases: ["غادر", "leave"],
    description: "يجعل البوت يغادر المجموعة الحالية.",
    category: "group",
    
    // ✨ صلاحيات مهمة جدًا للأمان ✨
    group: true, // هذا الأمر يعمل فقط في المجموعات

    async run({ reply, message, sock, isGroup, isAdmin, isDeveloper }) {
        // 1. التحقق من الصلاحيات: هل المستخدم هو المطور أو مشرف في المجموعة؟
        if (!isAdmin && !isDeveloper) {
            return reply("❌ هذا الأمر مخصص لمشرفي المجموعة والمطور فقط.");
        }

        // تأخير بسيط (2 ثانية) قبل المغادرة لإعطاء فرصة للمستخدم لقراءة الرسالة
        await new Promise(resolve => setTimeout(resolve, 2000));

        try {
            // 3. ✨ الدالة الأساسية: مغادرة المجموعة ✨
            // نستخدم 'message.key.remoteJid' الذي يحتوي على معرف المجموعة الحالية
            await sock.groupLeave(message.key.remoteJid);

        } catch (error) {
            console.error("Error leaving group:", error);
            // في حالة حدوث خطأ، يتم إرسال رسالة في الخاص للمطور
            // هذا مفيد إذا كان البوت ليس لديه صلاحية المغادرة (نادر جدًا)
            await sock.sendMessage(handler.bot.config.DEVELOPERS[0], {
                text: `❌ فشلت محاولة الخروج من المجموعة: ${message.key.remoteJid}\n\n*السبب:* ${error.message}`
            });
        }
    }
};