export default {
  name: "عشوائي",
  description: "منشن عشوائي لعضو من القروب",
  async run({ sock, message }) {
    const gid = message.key.remoteJid;

    const metadata = await sock.groupMetadata(gid);
    const members = metadata.participants.map(p => p.id);

    if (members.length === 0) {
      return sock.sendMessage(gid, { text: "ما كاين حتى عضو فالقروب 🌚" });
    }

    const random = members[Math.floor(Math.random() * members.length)];

    await sock.sendMessage(gid, {
      text: `🎯 @${random.split("@")[0]}`,
      mentions: [random]
    });
  }
};