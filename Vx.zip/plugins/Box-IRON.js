import fs from "fs-extra";

import path from "path";

// الدالة لاختيار n عناصر مختلفة عشوائياً حسب الاحتمالات

function getRandomUnique(items, n) {

    const selected = [];

    const copy = [...items]; // نسخة لتجنب تعديل الأصلي

    while (selected.length < n && copy.length > 0) {

        const total = copy.reduce((sum, i) => sum + i.chance, 0);

        let r = Math.random() * total;

        for (let i = 0; i < copy.length; i++) {

            if (r < copy[i].chance) {

                selected.push(copy[i].name);

                copy.splice(i, 1); // إزالة العنصر لتجنب التكرار

                break;

            }

            r -= copy[i].chance;

        }

    }

    return selected;

}

export default {

    name: "حديدي",

    description: "صندوق الحظ الحديدي مع اختيار 3-6 اشياء عشوائية بدون تكرار",

    async run({ reply }) {

        try {

            // **تغيير مسار الملف إلى Iron.json**

            const dataPath = path.join(process.cwd(), "data", "Iron.json");

            const allItems = await fs.readJSON(dataPath); // JSON يحتوي على {name, chance}

            // **اختيار عدد العناصر بين 3 و 6**

            // Math.floor(Math.random() * 4) يعطي 0 أو 1 أو 2 أو 3. إضافة 3 يجعلها 3 أو 4 أو 5 أو 6.

            const itemsToSelect = Math.floor(Math.random() * 4) + 3;

            const chosen = getRandomUnique(allItems, itemsToSelect);

            const itemsText = chosen.map(i => `• ${i}`).join("\n");

            // **تعديل نموذج الرد ليناسب الصندوق الحديدي**

            const form = `

˼‏˹↫𝑽 𝑰 𝑷⊰☀⊱𝑺 𝑻 𝑶 𝑹 𝑬

╔⟐━─⧉━⌬〔☀️〕⌬━⧉─━⟐╗

تعلن ادارة

˼‏˹↫الشمس⊰☀⊱𝑺.𝑼.𝑵

⟐━─⧉━〘 صندوق الحظ 〙━⧉─━⟐

❀ النوع:『حديدي』

❀ الوصف:『الحصول على 3-6 اشياء غير عادية مع احتمال 25% الحصول على اشياء عادية او نادرة』

❀ المشـ✨ـتري:『』

❀ الاشـ📦ـياء:『${itemsText}』

❀ السـ💎ـعر:『1M』

❀ المسـ👤ـؤول:『』

ملاحظة‼️ مرة واحدة هو الحد الاسبوعي للصندوق الحديدي يتم تسجيله في البنك

ملاحظة‼️ مستوى الاشياء: مستحيل > اسطوري > نادر > غير عادي > عادي

˼‏˹↫𝑽 𝑰 𝑷⊰☀⊱𝑺 𝑻 𝑶 𝑹 𝑬

〄━═─⧉━⌬〔☀️〕⌬━⧉─═━〄

˼‏˹↫الشمس⊰☀⊱𝑺.𝑼.𝑵

`;

            await reply(form);

        } catch (err) {

            console.error(err);

            reply("⚠️ حصل خطأ أثناء قراءة ملف الأشياء (Iron.json).");

        }

    }

};

