import fs from "fs";
import path from "path";

export default {
    name: "اضافه",
    developer: true,
    async run({ message, reply, args }) {
        try {
            const cmdName = args[0];
            if (!cmdName) return reply("❌ حدد اسم الأمر الذي تريد إضافته.");

            // خذ المحتوى من الرد على رسالة
            const content = message.message?.extendedTextMessage?.contextInfo?.quotedMessage?.conversation;
            if (!content) return reply("❌ رُد على رسالة ليتم إضافتها كأمر.");

            // مجلد plugins
            const pluginsDir = path.join("./plugins");
            if (!fs.existsSync(pluginsDir)) fs.mkdirSync(pluginsDir, { recursive: true });

            const filePath = path.join(pluginsDir, `${cmdName}.js`);

            if (fs.existsSync(filePath)) return reply("❌ هذا الأمر موجود بالفعل.");

            // ضع الكود في الملف كما هو
            fs.writeFileSync(filePath, content.trim());
            reply(`✅ تم إنشاء الأمر: .${cmdName}`);
        } catch (err) {
            reply("❌ خطأ: " + err.message);
        }
    }
};