import fs from 'fs/promises';
import path from 'path';

// المسار الكامل لملف الكونفج
const configPath = path.resolve(process.cwd(), 'config.js');

// دالة لقراءة وكتابة الكونفج
async function updateConfigMode(newMode) {
    try {
        let fileContent = await fs.readFile(configPath, 'utf8');
        
        // استخدام تعبير نمطي (Regex) لتحديث قيمة MODE
        // هذا التعبير يبحث عن: MODE: "public" أو MODE: 'private'
        const updatedContent = fileContent.replace(
            /MODE\s*:\s*['"](public|private)['"]/,
            `MODE: "${newMode}"`
        );

        // إذا لم يتم العثور على السطر (كخطة بديلة)، نقوم بإضافته
        if (updatedContent === fileContent) {
            console.log("لم يتم العثور على سطر MODE، سيتم محاولة إضافة جديد (هذا لا يجب أن يحدث).");
            return false; // من الأفضل عدم المتابعة لتجنب إفساد الملف
        }

        await fs.writeFile(configPath, updatedContent, 'utf8');
        return true;
    } catch (error) {
        console.error('❌ خطأ في تحديث ملف الكونفج:', error);
        return false;
    }
}

export default {
    name: "mode",
    description: "تغيير وضع البوت (عام/مطورين) وحفظه بشكل دائم.",
    aliases: ["وضع", "مود"],
    category: "developer",
    developer: true,
    
    async run({ bot, m, args, reply }) { // تم تبسيط `message` إلى `m` و `handler` لم يعد مطلوبًا هنا
        const currentMode = bot.config.MODE === 'private' ? '🔒 المطورين فقط' : '🌍 الوضع العام';

        if (args.length === 0) {
            return reply(
                `⚙️ *الوضع الحالي:* ${currentMode}\n\n` +
                `🔹 *الاستخدام:*\n` +
                `• \`${bot.config.PREFIX}mode on\` - 🔒 وضع المطورين فقط\n` +
                `• \`${bot.config.PREFIX}mode off\` - 🌍 الوضع العام للجميع`
            );
        }

        const requestedMode = args[0].toLowerCase();
        let newModeValue = null;
        let successMessage = '';

        if (requestedMode === 'on' || requestedMode === 'private') {
            if (bot.config.MODE === 'private') {
                return reply('✅ وضع المطورين مُفعّل بالفعل.');
            }
            newModeValue = 'private';
            successMessage = '🔒 *تم تفعيل وضع المطورين فقط*\n\n✅ الآن البوت يستجيب للمطورين فقط.';
        } else if (requestedMode === 'off' || requestedMode === 'public') {
            if (bot.config.MODE === 'public') {
                return reply('✅ الوضع العام مُفعّل بالفعل.');
            }
            newModeValue = 'public';
            successMessage = '🌍 *تم تفعيل الوضع العام*\n\n✅ الآن البوت يستجيب للجميع.';
        } else {
            return reply(
                '❌ *استخدام خاطئ!*\n\n' +
                `• \`${bot.config.PREFIX}mode on\` - لوضع المطورين فقط\n` +
                `• \`${bot.config.PREFIX}mode off\` - للوضع العام`
            );
        }

        // تحديث الكونفج في الذاكرة المؤقتة أولاً
        bot.config.MODE = newModeValue;

        // الآن، قم بتحديث الملف الفعلي
        const success = await updateConfigMode(newModeValue);

        if (success) {
            await reply(successMessage);
            // لا حاجة لإعادة تشغيل البوت لأن الهاندلر يقرأ من bot.config مباشرة
        } else {
            // إذا فشل الحفظ، تراجع عن التغيير في الذاكرة
            bot.config.MODE = currentMode.includes('العام') ? 'public' : 'private';
            await reply('❌ فشلت عملية تحديث ملف `config.js`. لم يتم حفظ التغيير.');
        }
    }
};