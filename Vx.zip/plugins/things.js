import fs from "fs-extra";
import path from "path";

export default {
  name: "سلع",
  description: "إرسال الاستمارة كما هي من ملف الداتا",
  async run({ reply }) {
    try {
      const formPath = path.join(process.cwd(), "data", "itemsForm.txt"); 
      // الملف يحتوي الاستمارة كما تريدها
      const formContent = await fs.readFile(formPath, "utf8");

      await reply(formContent);
    } catch (err) {
      console.error(err);
      reply("⚠️ ما قدرت أجيب الاستمارة، شيك على الملف.");
    }
  },
};