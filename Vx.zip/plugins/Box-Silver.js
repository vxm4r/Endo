import fs from "fs-extra";
import path from "path";

// الدالة لاختيار n عناصر مختلفة عشوائياً حسب الاحتمالات
function getRandomUnique(items, n) {
    const selected = [];
    const copy = [...items]; // نسخة لتجنب تعديل الأصلي

    while (selected.length < n && copy.length > 0) {
        const total = copy.reduce((sum, i) => sum + i.chance, 0);
        let r = Math.random() * total;

        for (let i = 0; i < copy.length; i++) {
            if (r < copy[i].chance) {
                selected.push(copy[i].name);
                copy.splice(i, 1); // إزالة العنصر لتجنب التكرار
                break;
            }
            r -= copy[i].chance;
        }

    }

    return selected;
}

export default {
    name: "فضي",
    description: "صندوق الحظ الفضي مع اختيار 3-5 اشياء عشوائية بدون تكرار",
    async run({ reply }) {
        try {
            // **تغيير مسار الملف إلى Silver.json**
            const dataPath = path.join(process.cwd(), "data", "Silver.json");
            const allItems = await fs.readJSON(dataPath); // JSON يحتوي على {name, chance}

            // **اختيار عدد العناصر بين 3 و 5**
            // Math.floor(Math.random() * 3) يعطي 0 أو 1 أو 2. إضافة 3 يجعلها 3 أو 4 أو 5.
            const itemsToSelect = Math.floor(Math.random() * 3) + 3;
            const chosen = getRandomUnique(allItems, itemsToSelect);

            const itemsText = chosen.map(i => `• ${i}`).join("\n");

            // **تعديل نموذج الرد ليناسب الصندوق الفضي**
            const form = `

˼‏˹↫𝑽 𝑰 𝑷⊰☀⊱𝑺 𝑻 𝑶 𝑹 𝑬

╔⟐━─⧉━⌬〔☀️〕⌬━⧉─━⟐╗

تعلن ادارة
˼‏˹↫الشمس⊰☀⊱𝑺.𝑼.𝑵

⟐━─⧉━〘 صندوق الحظ 〙━⧉─━⟐

❀ النوع:『فضي』
❀ الوصف:『الحصول على 3-5 اشياء نادرة مع احتمال 25% الحصول على اشياء غير عادية او اشياء اسطورية』
❀ المشـ✨ـتري:『』
❀ الاشـ📦ـياء:『${itemsText}』
❀ السـ💎ـعر:『1.5M』
❀ المسـ👤ـؤول:『』

ملاحظة‼️ مرة واحدة هو الحد الاسبوعي للصندوق الفضي يتم تسجيله في البنك
ملاحظة‼️ مستوى الاشياء: مستحيل > اسطوري > نادر > غير عادي > عادي

˼‏˹↫𝑽 𝑰 𝑷⊰☀⊱𝑺 𝑻 𝑶 𝑹 𝑬

〄━═─⧉━⌬〔☀️〕⌬━⧉─═━〄
˼‏˹↫الشمس⊰☀⊱𝑺.𝑼.𝑵
`;

            await reply(form);

        } catch (err) {
            console.error(err);
            reply("⚠️ حصل خطأ أثناء قراءة ملف الأشياء (Silver.json).");
        }

    }
};
