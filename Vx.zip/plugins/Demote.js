// ملف: plugins/خفض.js (معدل للمشرفين والمطورين)

export default {
    name: "خفض",
    
    description: "تنزيل مشرف إلى عضو عادي.",
    category: "admin",
    usage: ".خفض (رد أو منشن)",
    
    // الصلاحيات الأساسية
    group: true,     // يعمل في المجموعات فقط
    

    async run({ sock, message, reply, args, isDeveloper }) {
        // --- التحقق من صلاحيات المستخدم (مشرف أو مطور) ---
        const metadata = await sock.groupMetadata(message.key.remoteJid);
        const sender = metadata.participants.find(p => p.id === message.key.participant);
        const isAdmin = sender?.admin === 'admin' || sender?.admin === 'superadmin';

        if (!isAdmin && !isDeveloper) {
            return reply("❌ هذا الأمر للمشرفين والمطور فقط.");
        }

        try {
            let target;

            // تحديد الهدف (من الرد أو المنشن)
            const quoted = message.message?.extendedTextMessage?.contextInfo;
            if (quoted?.participant) {
                target = quoted.participant;
            } else {
                const mentions = message.message?.extendedTextMessage?.contextInfo?.mentionedJid;
                if (mentions?.length > 0) {
                    target = mentions[0];
                }
            }

            // التحقق من وجود هدف
            if (!target) {
                return reply("❌ قم بالرد على المشرف الذي تريد تنزيله أو قم بعمل منشن له.");
            }

            // التحقق مما إذا كان الهدف هو البوت نفسه
            if (target === sock.user.id) {
                return reply("🤔 لا يمكنني تنزيل نفسي.");
            }

            // التحقق مما إذا كان الهدف مشرفًا بالفعل
            const targetParticipant = metadata.participants.find(p => p.id === target);
            if (!targetParticipant?.admin) {
                return reply("⚠️ هذا العضو ليس مشرفًا بالفعل.");
            }
            
            // التحقق مما إذا كان الهدف هو مالك المجموعة (لا يمكن تنزيله)
            if (targetParticipant.admin === 'superadmin') {
                return reply("❌ لا يمكن تنزيل مالك المجموعة.");
            }

            // تنفيذ التنزيل
            await sock.groupParticipantsUpdate(message.key.remoteJid, [target], "demote");
            
            // إرسال رسالة نجاح مع منشن للشخص الذي تم تنزيله
            await reply(`✅ تم تنزيل @${target.split('@')[0]} إلى عضو عادي.`, {
                mentions: [target]
            });

        } catch (error) {
            console.error("Error in 'خفض' command:", error);
            // التعامل مع الأخطاء الشائعة
            if (error.message.includes('not-admin')) {
                await reply("❌ فشلت العملية. يجب أن يكون البوت مشرفًا لتنفيذ هذا الأمر.");
            } else {
                await reply(`❌ حدث خطأ: ${error.message}`);
            }
        }
    }
};