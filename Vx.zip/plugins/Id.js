import moment from 'moment-timezone';
import { parsePhoneNumberFromString } from 'libphonenumber-js';

// دالة للحصول على معلومات الدولة، تبقى كما هي
function getCountryInfo(phoneNumber) {
    try {
        const phone = parsePhoneNumberFromString(`+${phoneNumber}`);
        if (phone && phone.country) {
            const countryCode = phone.country;
            const countryName = new Intl.DisplayNames(['ar'], { type: 'region' }).of(countryCode);
            const getFlag = (code) => String.fromCodePoint(...[...code.toUpperCase()].map(char => 0x1F1A5 + char.charCodeAt(0)));
            return `${getFlag(countryCode)} ${countryName}`;
        }
        return 'غير معروفة';
    } catch (error) {
        console.error("Error parsing phone number:", error);
        return 'غير معروفة';
    }
}

export default {
    name: "ايدي",
    description: "يعرض ملفًا شخصيًا احترافيًا ومتكاملًا للمستخدم.",
    category: "عام",
    usage: ".ايدي [@منشن|بالرد]",
    group: true,

    async run({ sock, m, args, reply }) {
        try {
            const contextInfo = m.message?.extendedTextMessage?.contextInfo;
            const quotedSender = contextInfo?.participant;
            const mentionedJid = contextInfo?.mentionedJid || [];
            
            const targetId = quotedSender || (mentionedJid.length > 0 ? mentionedJid[0] : m.key.participant);

            if (!targetId) {
                return reply("❌ لم أتمكن من تحديد مستخدم صالح.");
            }

            const metadata = await sock.groupMetadata(m.key.remoteJid);
            const participant = metadata.participants.find(p => p.id === targetId);

            if (!participant) {
                return reply("❌ لا يمكن العثور على هذا المستخدم في المجموعة.");
            }

            const realJid = participant.phoneNumber;
            if (!realJid) {
                return reply("❌ لا يمكن الحصول على رقم الهاتف الحقيقي لهذا المستخدم.");
            }

            const realLid = participant.id.endsWith('@lid') ? participant.id : null;
            const number = realJid.split('@')[0];
            const displayName = participant.notify || number;
            const isAdmin = participant.admin === 'admin' || participant.admin === 'superadmin';
            
            // ✨✨ [الإصلاح النهائي بناءً على التشخيص] ✨✨
            // 1. جلب الصورة والبيانات الأخرى بالتوازي
            const [statusResult, pfpResult] = await Promise.allSettled([
                sock.fetchStatus(realJid),
                sock.profilePictureUrl(realJid, 'image')
            ]);

            // 2. استخلاص البايو والتاريخ من `fetchStatus` بالطريقة الصحيحة
            let userBio = 'لا يوجد بايو.';
            let lastSeen = 'غير متاح (بسبب الخصوصية) 🔒';
            if (statusResult.status === 'fulfilled' && statusResult.value[0]?.status) {
                const statusData = statusResult.value[0].status;
                userBio = statusData.status || userBio;
                if (statusData.setAt) {
                    moment.locale('ar');
                    lastSeen = `(تم تحديثه ${moment(statusData.setAt).fromNow()})`;
                }
            }

            const profilePicUrl = (pfpResult.status === 'fulfilled') ? pfpResult.value : null;
            
            // 3. بناء بقية المعلومات
            const countryInfo = getCountryInfo(number); 
            const directLink = `https://wa.me/${number}`;
            const adminStatus = isAdmin ? 'مشرف 🛡️' : 'عضو 👥';
            // لا يمكن تحديد نوع الحساب بشكل موثوق الآن لأن onWhatsApp فشلت
            const accountType = 'غير محدد'; 

            const replyText = `
╭── • ⋅⚜️⋅ • ──╮
  *مـلـف تـعـريـفـي*
╰── • ⋅⚜️⋅ • ──╯

*✨ ┆ الاسـم:* ${displayName}
*👤 ┆ المنشن:* @${number}
*📝 ┆ البـايـو:* ${userBio}

- - - - - - - - - - - - - - - - -

*🆔 ┆ JID:* \`${realJid}\`
*🔍 ┆ LID:* \`${realLid || 'غير متوفر'}\`
*👑 ┆ الصلاحية:* ${adminStatus}

- - - - - - - - - - - - - - - - -

*📊 ┆ نـوع الحسـاب:* ${accountType}
*🌍 ┆ الـدولـة:* ${countryInfo}
*🕒 ┆ آخر تحديث للبايو:* ${lastSeen}
*🔗 ┆ رابـط:* ${directLink}

. ▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭ .
`;
            
            const messageOptions = {
                [profilePicUrl ? 'image' : 'text']: profilePicUrl ? { url: profilePicUrl } : replyText.trim(),
                ...(profilePicUrl && { caption: replyText.trim() }),
                mentions: [realJid]
            };

            await sock.sendMessage(m.key.remoteJid, messageOptions, { quoted: m });

        } catch (error) {
            console.error('✗ خطأ في أمر ايدي:', error);
            await reply(`❌ *حدث خطأ:* ${error.message}`);
        }
    }
};