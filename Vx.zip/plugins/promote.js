// ملف: plugins/ادمن.js (معدل للمشرفين والمطورين)

export default {
    name: "ادمن",
    aliases: ["promote"],
    description: "ترقية عضو إلى مشرف.",
    category: "admin",
    usage: ".ادمن (رد أو منشن)",
    
    // الصلاحيات الأساسية
    group: true,     // يعمل في المجموعات فقط
   
    async run({ sock, message, reply, args, isDeveloper }) {
        // --- التحقق من صلاحيات المستخدم (مشرف أو مطور) ---
        const metadata = await sock.groupMetadata(message.key.remoteJid);
        const sender = metadata.participants.find(p => p.id === message.key.participant);
        const isAdmin = sender?.admin === 'admin' || sender?.admin === 'superadmin';

        if (!isAdmin && !isDeveloper) {
            return reply("❌ هذا الأمر للمشرفين والمطور فقط.");
        }
        try {
            let target;
            // تحديد الهدف (من الرد أو المنشن)
            const quoted = message.message?.extendedTextMessage?.contextInfo;
            if (quoted?.participant) {
                target = quoted.participant;
            } else {
                const mentions = message.message?.extendedTextMessage?.contextInfo?.mentionedJid;
                if (mentions?.length > 0) {
                    target = mentions[0];
                }
            }

            // التحقق من وجود هدف
            if (!target) {
                return reply("❌ قم بالرد على الشخص الذي تريد ترقيته أو قم بعمل منشن له.");
            }

            // التحقق مما إذا كان الهدف هو البوت نفسه
            if (target === sock.user.id) {
                return reply("🤔 لا يمكنني ترقية نفسي، أنا مشرف بالفعل (أو يجب أن أكون).");
            }

            // التحقق مما إذا كان الهدف مشرفًا بالفعل
            const targetParticipant = metadata.participants.find(p => p.id === target);
            if (targetParticipant?.admin) {
                return reply("⚠️ هذا العضو مشرف بالفعل.");
            }

            // تنفيذ الترقية
            await sock.groupParticipantsUpdate(message.key.remoteJid, [target], "promote");
            
            // إرسال رسالة نجاح مع منشن للشخص الذي تمت ترقيته
            await reply(`✅ تم ترقية @${target.split('@')[0]} إلى مشرف.`, {
                mentions: [target]
            });

        } catch (error) {
            console.error("Error in 'ادمن' command:", error);
            // التعامل مع الأخطاء الشائعة
            if (error.message.includes('not-admin')) {
                await reply("❌ فشلت الترقية. يجب أن يكون البوت مشرفًا لتنفيذ هذا الأمر.");
            } else {
                await reply(`❌ حدث خطأ: ${error.message}`);
            }
        }
    }
};