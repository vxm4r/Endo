// ملف: plugins/وصف.js (معدل للمشرفين والمطورين)

export default {
    name: "وصف",
    description: "تغيير وصف المجموعة.",
    category: "admin",

    // الصلاحيات الأساسية
    group: true, // يعمل في المجموعات فقط
    

    async run({ sock, message, reply, text, isDeveloper }) {
        // --- التحقق من الصلاحيات (مشرف أو مطور) ---
        const metadata = await sock.groupMetadata(message.key.remoteJid);
        const sender = metadata.participants.find(p => p.id === message.key.participant);
        const isAdmin = sender?.admin === 'admin' || sender?.admin === 'superadmin';

        if (!isAdmin && !isDeveloper) {
            return reply("❌ هذا الأمر للمشرفين والمطور فقط.");
        }

        try {
            // 1. استدعاء دالة Baileys الرسمية لتغيير الوصف
            // 'text' هنا هو الوصف الجديد. إذا كان فارغًا، سيتم حذف الوصف.
            await sock.groupUpdateDescription(message.key.remoteJid, text);

            // 2. إرسال رسالة نجاح
            if (text) {
                await reply(`✅ تم تغيير وصف المجموعة بنجاح.`);
            } else {
                await reply(`✅ تم حذف وصف المجموعة بنجاح.`);
            }

        } catch (error) {
            console.error("Error in 'وصف' command:", error);
            await reply(`❌ *حدث خطأ أثناء تغيير وصف المجموعة:*\n${error.message}`);
        }
    }
};