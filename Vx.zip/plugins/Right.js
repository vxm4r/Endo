import webpmux from "node-webpmux";

export default {
    name: "حقوق",
    description: "إضافة حقوق (اسم الحزمة والمؤلف) إلى الملصقات الثابتة والمتحركة.",
    aliases: ["vm", "take"],
    category: "sticker",

    async run({ message, reply, text, downloadMedia }) {
        try {
            // 1. التحقق من وجود ملصق في الرد
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            const stickerMessage = quoted?.stickerMessage;

            if (!stickerMessage) {
                return reply("❌ *خطأ:* يرجى الرد على ملصق (ثابت أو متحرك) لتعديل حقوقه.");
            }

            // 2. معالجة النصوص (اسم الحزمة والمؤلف)
            // نستخدم الفاصل | أو الفاصل الخاص بك • ⃟🌑•
            let packname = '𝐕𝐈𝐏🐦‍🔥𝐒𝐔𝐍';
            let author = '𝐕𝐗';

            if (text) {
                const parts = text.split('|').map(p => p.trim());
                if (parts[0]) packname = parts[0];
                if (parts[1]) author = parts[1];
            }

            // 3. تحميل الملصق الأصلي
            // دالة downloadMedia ستجلب ملف الـ webp سواء كان متحركاً أو لا
            const stickerBuffer = await downloadMedia(message);
            if (!stickerBuffer) {
                return reply("❌ فشل تحميل الملصق الأصلي.");
            }

            // 4. استخدام webpmux لمعالجة البيانات الوصفية (EXIF)
            const img = new webpmux.Image();
            await img.load(stickerBuffer);

            // 5. إعداد بيانات الحقوق الجديدة
            const exifData = {
                "sticker-pack-id": `king-solo-${Date.now()}`, // معرف فريد لمنع تداخل التخزين
                "sticker-pack-name": packname,
                "sticker-pack-publisher": author,
                "emojis": ["⚡️"],
            };
            
            // بناء الـ Buffer الخاص بالـ EXIF
            const exifHeader = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
            const jsonBuffer = Buffer.from(JSON.stringify(exifData), "utf-8");
            const exifFinal = Buffer.concat([exifHeader, jsonBuffer]);
            exifFinal.writeUIntLE(jsonBuffer.length, 14, 4);

            // 6. حقن الحقوق في ملف الملصق
            // ملاحظة: webpmux تحافظ على إطارات الحركة في الملصقات المتحركة تلقائياً
            img.exif = exifFinal;

            // 7. إرسال الملصق الجديد
            await reply({
                sticker: await img.save(null)
            });

        } catch (error) {
            console.error("Error in 'حقوق' command:", error);
            await reply(`❌ *فشل تعديل الحقوق:* ${error.message}`);
        }
    }
};
