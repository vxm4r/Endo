import fs from "fs-extra";
import path from "path";

// الدالة لاختيار n عناصر مختلفة عشوائياً حسب الاحتمالات
function getRandomUnique(items, n = 1) {
    const selected = [];
    // يجب أن تكون items نسخة لضمان عدم تغيير الأصل إذا تم استخدامها لاحقًا
    const copy = [...items]; 

    while (selected.length < n && copy.length > 0) {
        // حساب المجموع الكلي لاحتمالات العناصر المتبقية
        const total = copy.reduce((sum, i) => sum + i.chance, 0);
        // توليد رقم عشوائي بين 0 والمجموع الكلي
        let r = Math.random() * total;

        for (let i = 0; i < copy.length; i++) {
            // التحقق من أن الرقم العشوائي يقع ضمن مدى احتمال العنصر الحالي
            if (r < copy[i].chance) {
                selected.push(copy[i].name);
                // إزالة العنصر المختار من النسخة لضمان الاختيار الفريد
                copy.splice(i, 1);
                break;
            }
            // إذا لم يكن العنصر الحالي هو المختار، اطرح احتماله للمقارنة مع العنصر التالي
            r -= copy[i].chance;
        }
    }

    return selected;
}

export default {
    // تغيير اسم الأمر إلى "عاديه"
    name: "عاديه",
    command: ["عاديه", "normal"], 
    description: "تفعيل عجلة الحظ العادية للحصول على جائزة واحدة أو أكثر",
    category: "STORE",
    // **أضف 'args' لاستقبال الوسائط (مثل 1, 2, 3)**
    async run({ reply, args }) {
        try {
            const dataPath = path.join(process.cwd(), "data", "WheelNormal.json");
            const allItems = await fs.readJSON(dataPath); 

            // **تعديل: قراءة عدد مرات التشغيل المطلوبة**
            // تحويل أول وسيط (إذا وُجد) إلى عدد صحيح. القيمة الافتراضية هي 1 إذا لم يتم إدخال شيء أو كان المدخل غير صالح.
            // القيمة القصوى محددة بـ 3 حسب ملاحظتك، لذا نستخدم Math.min لتحديد الحد الأقصى بـ 3.
            const runCount = Math.min(parseInt(args[0]) || 1, 3);

            // اختيار العناصر بعدد مرات التشغيل
            const chosen = getRandomUnique(allItems, runCount);

            // تنسيق قائمة الجوائز
            const itemText = chosen.length > 0 
                ? chosen.map(item => `• ${item}`).join("\n") 
                : "لم يتم اختيار أي شيء.";

            // **تعديل نموذج الرد ليناسب الأمر الجديد**
            const form = `
˼‏˹↫𝑽 𝑰 𝑷⊰☀⊱𝑺 𝑻 𝑶 𝑹 𝑬

╔⟐━─⧉━⌬〔☀️〕⌬━⧉─━⟐╗

تعلن ادارة
˼‏˹↫الشمس⊰☀⊱𝑺.𝑼.𝑵

⟐━─⧉━〘 🎡 عجلة الحظ 〙━⧉─━⟐

❀ النوع:『عادية』
❀ عدد التشغيل:『${runCount} مرة』
❀ الجائزة:『الحصول على ${runCount} جائزة عشوائية مع احتمال 50% للحصول على مال』
❀ المشـ✨ـتري:『』
❀ الاشـ📦ـياء:
${itemText}
❀ السـ💎ـعر:『${runCount * 500}k』
❀ المسـ👤ـؤول:『』

ملاحظة‼️ ثلاث مرات هو الحد اليومي للعجلة العادية يتم تسجيل عددها في البنك.
ملاحظة‼️ يمكنك استخدام الأمر بهذا الشكل: *.عاديه 1* أو *.عاديه 2* أو *.عاديه 3* لتحديد عدد مرات التشغيل.

˼‏˹↫𝑽 𝑰 𝑷⊰☀⊱𝑺 𝑻 𝑶 𝑹 𝑬

〄━═─⧉━⌬〔☀️〕⌬━⧉─═━〄
˼‏˹↫الشمس⊰☀⊱𝑺.𝑼.𝑵
`;

            await reply(form);

        } catch (err) {
            console.error(err);
            reply("⚠️ حصل خطأ أثناء قراءة ملف الأشياء (WheelNormal.json).");
        }

    }
};
