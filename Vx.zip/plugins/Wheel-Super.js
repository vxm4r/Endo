import fs from "fs-extra";
import path from "path";

// الدالة لاختيار عنصر واحد عشوائياً حسب الاحتمالات
function getRandomUnique(items, n = 1) {
    const selected = [];
    const copy = [...items]; 

    while (selected.length < n && copy.length > 0) {
        const total = copy.reduce((sum, i) => sum + i.chance, 0);
        let r = Math.random() * total;

        for (let i = 0; i < copy.length; i++) {
            if (r < copy[i].chance) {
                selected.push(copy[i].name);
                break;
            }
            r -= copy[i].chance;
        }
    }

    return selected;
}

export default {
    // تغيير اسم الأمر إلى "خارق"
    name: "خارق",
    command: ["خارق", "superwheel"], 
    description: "تفعيل عجلة الحظ الخارقة للحصول على جائزة واحدة نادرة",
    category: "STORE",
    async run({ reply }) {
        try {
            // **تغيير مسار الملف إلى WheelSuper.json**
            const dataPath = path.join(process.cwd(), "data", "WheelSuper.json");
            const allItems = await fs.readJSON(dataPath); 

            // اختيار عنصر واحد فقط
            const chosen = getRandomUnique(allItems, 1);
            const itemText = chosen.length > 0 ? `• ${chosen[0]}` : "لم يتم اختيار أي شيء.";

            // **تعديل نموذج الرد ليناسب العجلة الخارقة**
            const form = `
˼‏˹↫𝑽 𝑰 𝑷⊰☀⊱𝑺 𝑻 𝑶 𝑹 𝑬

╔⟐━─⧉━⌬〔☀️〕⌬━⧉─━⟐╗

تعلن ادارة
˼‏˹↫الشمس⊰☀⊱𝑺.𝑼.𝑵

⟐━─⧉━〘 🌟 عجلة الحظ 〙━⧉─━⟐

❀ النوع:『خارق』
❀ الجائزة:『الحصول على جائزة واحدة نادرة أو أسطورية』
❀ المشـ✨ـتري:『』
❀ الاشـ📦ـياء:
${itemText}
❀ السـ💎ـعر:『1.5M』
❀ المسـ👤ـؤول:『』

ملاحظة‼️ مرة واحدة هو الحد اليومي للعجلة الخارقة يتم تسجيلها في البنك.

˼‏˹↫𝑽 𝑰 𝑷⊰☀⊱𝑺 𝑻 𝑶 𝑹 𝑬

〄━═─⧉━⌬〔☀️〕⌬━⧉─═━〄
˼‏˹↫الشمس⊰☀⊱𝑺.𝑼.𝑵
`;

            await reply(form);

        } catch (err) {
            console.error(err);
            reply("⚠️ حصل خطأ أثناء قراءة ملف الأشياء (WheelSuper.json).");
        }

    }
};
