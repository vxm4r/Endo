// ملف: plugins/طرد.js

export default {
    name: "طرد",
    aliases: ["kick", "remove"],
    description: "يطرد عضوًا من المجموعة. استخدمه بالرد أو بالمنشن.",
    category: "admin",
    
    // --- الصلاحيات المطلوبة ---
    group: true,      // يجب أن يكون في مجموعة
    admin: true,      // يجب أن يكون المستخدم مشرفًا
    botAdmin: true,   // يجب أن يكون البوت مشرفًا

    async run({ sock, message, reply, args, handler }) {
        try {
            const groupJid = message.key.remoteJid;

            // --- تحديد الهدف (الضحية) ---
            let targetJid;

            // الطريقة الأولى: البحث عن طريق الرد على رسالة
            const quoted = message.message?.extendedTextMessage?.contextInfo;
            if (quoted?.participant) {
                targetJid = quoted.participant;
            }

            // الطريقة الثانية: البحث عن طريق المنشن
            const mentions = message.message?.extendedTextMessage?.contextInfo?.mentionedJid;
            if (!targetJid && mentions && mentions.length > 0) {
                targetJid = mentions[0];
            }

            // إذا لم يتم تحديد هدف بأي طريقة
            if (!targetJid) {
                return reply("❌ لم يتم تحديد الهدف. قم بالرد على رسالة الشخص أو قم بعمل منشن له.\n\n*مثال:*\n.طرد @الشخص");
            }

            // --- التحقق من عدم طرد النفس أو البوت أو المطور ---
            const selfJid = sock.user.id;
            if (targetJid === selfJid) {
                return reply("🤖 لا يمكنني طرد نفسي.");
            }
            if (handler.isDeveloper(targetJid)) {
                return reply("🛡️ لا يمكن طرد المطور.");
            }

            // --- تنفيذ الطرد ---
            await reply(`✈️ جاري طرد العضو...`);

            // استدعاء دالة Baileys الرسمية لتحديث المشاركين
            const response = await sock.groupParticipantsUpdate(
                groupJid, 
                [targetJid],
                "remove" // الإجراء هو "إزالة"
            );

            // التحقق من الرد (بعض إصدارات واتساب ترجع حالة)
            if (response[0]?.status === "200") {
                await reply(`✅ تم طرد @${targetJid.split('@')[0]} بنجاح.`, { mentions: [targetJid] });
            } else if (response[0]?.status === "404") {
                await reply(`⚠️ لم يتم العثور على العضو في المجموعة. ربما خرج بالفعل.`);
            } else if (response[0]?.status === "403") {
                await reply(`❌ ليس لدي صلاحية لطرد هذا الشخص. قد يكون مشرفًا أيضًا.`);
            } else {
                // رسالة عامة في حالة عدم وجود رد واضح
                await reply(`✅ تم تنفيذ أمر الطرد ضد @${targetJid.split('@')[0]}.`, { mentions: [targetJid] });
            }

        } catch (error) {
            console.error("Error in 'طرد' command:", error);
            await reply(`❌ حدث خطأ أثناء محاولة الطرد: ${error.message}`);
        }
    }
};