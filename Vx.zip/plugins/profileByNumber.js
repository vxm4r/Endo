import moment from 'moment-timezone';
import { parsePhoneNumberFromString } from 'libphonenumber-js';

/*
  أمر: بروفايل
  الوصف:
    - يقبل رقم هاتف (+دولي أو بدون +) ويجلب بروفايل WhatsApp للشخص حتى لو مش موجود معاك في مجموعة.
    - يدعم أيضاً الرد أو المنشن إن ما مررت رقم.
  الاستخدام:
    .بروفايل +9665XXXXXXXX
    .بروفايل 9665XXXXXXXX
    .بروفايل @منشن
    (أو بالرد على رسالة) .بروفايل
*/

function getCountryInfo(phoneNumber) {
    try {
        if (!phoneNumber) return 'غير معروفة';
        const normalized = phoneNumber.startsWith('+') ? phoneNumber : `+${phoneNumber}`;
        const phone = parsePhoneNumberFromString(normalized);
        if (phone && phone.country) {
            const countryCode = phone.country;
            const countryName = new Intl.DisplayNames(['ar'], { type: 'region' }).of(countryCode);
            const getFlag = (code) =>
                code.toUpperCase()
                    .split('')
                    .map(ch => String.fromCodePoint(0x1F1E6 + ch.charCodeAt(0) - 65))
                    .join('');
            return `${getFlag(countryCode)} ${countryName || countryCode}`;
        }
        return 'غير معروفة';
    } catch (error) {
        console.error("Error parsing phone number:", error);
        return 'غير معروفة';
    }
}

async function tryFetchForJids(sock, jids) {
    // يحاول جلب البيانات لكل jid ويعيد أول نتيجة مفيدة
    for (const jid of jids) {
        try {
            const [statusRes, pfpRes, nameRes] = await Promise.allSettled([
                sock.fetchStatus ? sock.fetchStatus(jid) : Promise.resolve(null),
                sock.profilePictureUrl ? sock.profilePictureUrl(jid, 'image') : Promise.resolve(null),
                (typeof sock.getName === 'function') ? sock.getName(jid) : Promise.resolve(null)
            ]);
            const statusData = (statusRes.status === 'fulfilled' && statusRes.value)
                ? (Array.isArray(statusRes.value) ? statusRes.value[0] : statusRes.value)
                : null;
            const profilePicUrl = (pfpRes.status === 'fulfilled' && pfpRes.value) ? pfpRes.value : null;
            const name = (nameRes && nameRes.status === 'fulfilled' && nameRes.value) ? nameRes.value : null;

            if (profilePicUrl || statusData || name) {
                return { realJid: jid, profilePicUrl, statusData, name };
            }
        } catch (e) {
            // تابع المحاولة على الأشكال الأخرى
            continue;
        }
    }
    return null;
}

export default {
    name: "بروفايل",
    description: "يجلب بروفايل المستخدم برقم الهاتف أو بالرد/المنشن، حتى لو ليس معك في المجموعة.",
    category: "عام",
    usage: ".بروفايل [+رقم|@منشن|بالرد]",
    group: true,

    async run({ sock, m, args, reply }) {
        try {
            const contextInfo = m.message?.extendedTextMessage?.contextInfo;
            const quotedParticipant = contextInfo?.participant;
            const mentioned = contextInfo?.mentionedJid || [];

            // 1) اكتشاف إذا المستخدم أعطى رقم
            let input = (args && args[0]) ? args[0].trim() : null;
            let providedNumber = null;
            let targetJid = null;
            let fetchedInfo = null;

            if (input) {
                // تنظيف الرقم: اترك + والأرقام
                const cleaned = input.replace(/[^+\d]/g, '');
                const numOnly = cleaned.replace(/\D/g, '');
                if (!numOnly) return reply('❌ رقم غير صالح. الرجاء استخدام: .بروفايل +9665XXXXXXX');
                providedNumber = numOnly;

                // أشكال JID مرجحة
                const candidateJids = [
                    `${numOnly}@s.whatsapp.net`,
                    `${numOnly}@c.us`
                ];

                // 2) أفضل محاولة: استخدام onWhatsApp إذا متاحة للتحقق من وجود الحساب والحصول على jid الصحيح
                let realJidFromOn = null;
                if (typeof sock.onWhatsApp === 'function') {
                    try {
                        // onWhatsApp قد يقبل أرقام أو jids؛ نرسل الأشكال الشائعة
                        const check = await sock.onWhatsApp(candidateJids);
                        if (Array.isArray(check)) {
                            const found = check.find(r => r && (r.exists || r.jid));
                            if (found && found.jid) realJidFromOn = found.jid;
                        }
                    } catch (e) {
                        // تجاهل فشل onWhatsApp واستمر بمحاولات أخرى
                        console.warn('onWhatsApp failed:', e?.message || e);
                    }
                }

                if (realJidFromOn) {
                    targetJid = realJidFromOn;
                    // نحاول جلب بيانات مباشرة
                    fetchedInfo = await tryFetchForJids(sock, [targetJid]);
                } else {
                    // جرب fetchStatus/profilePictureUrl مباشرة على الأشكال المتوقعة
                    fetchedInfo = await tryFetchForJids(sock, candidateJids);
                    if (fetchedInfo) targetJid = fetchedInfo.realJid;
                    else targetJid = candidateJids[0]; // لا نوقف التنفيذ — سنعرض رسالة مناسبة لاحقاً إذا لم يوجد شيء
                }
            } else {
                // لا رقم: استخدام الرد أو المنشن أو المرسل
                const fallback = quotedParticipant || (mentioned.length > 0 ? mentioned[0] : m.sender);
                if (!fallback) return reply("❌ لم أتمكن من تحديد مستخدم صالح.");
                targetJid = fallback;
            }

            // 3) حاول الحصول على participant info لو الأمر جاء في جروب
            let participant = null;
            if (m.key && m.key.remoteJid && m.key.remoteJid.endsWith('@g.us')) {
                try {
                    const metadata = await sock.groupMetadata(m.key.remoteJid);
                    participant = metadata.participants.find(p => p.id === targetJid) || null;
                } catch (e) {
                    // تجاهل فشل جلب الميتاداتا
                }
            }

            const realJid = participant?.id || targetJid;
            if (!realJid) return reply("❌ لا يمكن الحصول على معرف هذا المستخدم.");

            const number = realJid.split('@')[0];

            // 4) إذا لم يجلب fetchedInfo مسبقاً، جلب الآن
            if (!fetchedInfo) {
                fetchedInfo = await tryFetchForJids(sock, [realJid]);
            }

            let displayName = participant?.notify || fetchedInfo?.name || null;
            if (!displayName) {
                try {
                    if (typeof sock.getName === 'function') {
                        displayName = await sock.getName(realJid);
                    }
                } catch (e) { /* ignore */ }
            }
            displayName = displayName || number;

            const isAdmin = participant ? (participant.admin === 'admin' || participant.admin === 'superadmin') : false;

            const statusData = fetchedInfo?.statusData || null;
            const profilePicUrl = fetchedInfo?.profilePicUrl || null;

            let userBio = 'لا يوجد بايو.';
            let lastSeen = 'غير متاح (بسبب الخصوصية) 🔒';
            if (statusData && (statusData.status || statusData.setAt)) {
                userBio = statusData.status || userBio;
                if (statusData.setAt) {
                    moment.locale('ar');
                    lastSeen = `(تم تحديثه ${moment(statusData.setAt).fromNow()})`;
                }
            }

            const countryInfo = getCountryInfo(providedNumber || number);
            const directLink = `https://wa.me/${number}`;
            const adminStatus = isAdmin ? 'مشرف 🛡️' : 'عضو 👥';
            const accountType = 'غير محدد';

            // إذا لم نجد أي بيانات (الشخص قد لا يكون على واتساب أو مخفي)، نبلغ المستخدم
            if (!profilePicUrl && !statusData && !fetchedInfo?.name && providedNumber) {
                return reply(`⚠️ لم أتمكن من العثور على بروفايل لهذا الرقم (${providedNumber}). قد لا يكون الرقم مسجلاً على WhatsApp أو أن الحساب مخفي/محمي.`);
            }

            const replyText = `
╭── • ⋅⚜️⋅ • ──╮
  *مـلـف تـعـريـفـي*
╰── • ⋅⚜️⋅ • ──╯

*✨ ┆ الاسـم:* ${displayName}
*👤 ┆ المنشن:* @${number}
*📝 ┆ البـايـو:* ${userBio}

- - - - - - - - - - - - - - - - -

*🆔 ┆ JID:* \`${realJid}\`
*🔍 ┆ LID:* \`${participant?.id?.endsWith('@lid') ? participant.id : 'غير متوفر'}\`
*👑 ┆ الصلاحية:* ${adminStatus}

- - - - - - - - - - - - - - - - -

*📊 ┆ نـوع الحسـاب:* ${accountType}
*🌍 ┆ الـدولـة:* ${countryInfo}
*🕒 ┆ آخر تحديث للبايو:* ${lastSeen}
*🔗 ┆ رابـط:* ${directLink}

. ▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭ .
`.trim();

            const mentions = [realJid];
            if (profilePicUrl) {
                await sock.sendMessage(m.key.remoteJid || m.key.participant || realJid, {
                    image: { url: profilePicUrl },
                    caption: replyText,
                }, { quoted: m, mentions });
            } else {
                await sock.sendMessage(m.key.remoteJid || m.key.participant || realJid, {
                    text: replyText
                }, { quoted: m, mentions });
            }

        } catch (error) {
            console.error('✗ خطأ في أمر بروفايل:', error);
            await reply(`❌ *حدث خطأ:* ${error?.message || error}`);
        }
    }
};