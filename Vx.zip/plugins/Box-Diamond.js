import fs from "fs-extra";
import path from "path";

// دالة الاختيار العشوائي
function getRandomUnique(items, n) {
  const selected = [];
  const copy = [...items]; 
  while (selected.length < n && copy.length > 0) {
    const total = copy.reduce((sum, i) => sum + i.chance, 0);
    let r = Math.random() * total;
    for (let i = 0; i < copy.length; i++) {
      if (r < copy[i].chance) {
        selected.push(copy[i].name);
        copy.splice(i, 1);
        break;
      }
      r -= copy[i].chance;
    }
  }
  return selected;
}

export default {
  name: "الماس",
  description: "صندوق الحظ الماسي - متجر الشمس",
  category: "shop",
  async run({ reply, args, m, sock }) {
    
    // تفاعل بالرموز التعبيرية
    if (m && m.key) {
      await sock.sendMessage(m.key.remoteJid, { react: { text: '💎', key: m.key } });
    }

    // تحديد المشتري والمسؤول
    const buyerNickname = (args && args.length > 0) ? args.join(" ") : (m.pushName || 'غير محدد');
    const adminName = m.pushName || 'إدارة الشمس';

    try {
      const dataPath = path.join(process.cwd(), "data", "Diamond.json");

      if (!fs.existsSync(dataPath)) {
          return reply("❌ خطأ: ملف Diamond.json غير موجود في مجلد data.");
      }

      const allItems = await fs.readJSON(dataPath);
      const chosen = getRandomUnique(allItems, 3);
      const itemsText = chosen.map(i => `• ${i}`).join("\n");

      const form = `
*˼‏˹↫𝑽 𝑰 𝑷⊰☀⊱𝑺 𝑻 𝑶 𝑹 𝑬*

*╔⟐━─⧉━⌬〔☀️〕⌬━⧉─━⟐╗*

*تعلن ادارة*
*˼‏˹↫الشمس⊰☀⊱𝑺.𝑼.𝑵*

*⟐━─⧉━〘 صندوق الحظ 〙━⧉─━⟐*

*❀ النوع:『الماسي』*
*❀ الوصف:『الحصول على 3 اشياء مستحيلة』*

*❀ المشـ✨ـتري:『${buyerNickname}』*

*❀ الاشياء:『\n${itemsText}』*

*❀ السـ💎ـعر:『2.5M』*

*❀ المسـ👤ـؤول:『${adminName}』*

*ملاحظة‼️ الحد الاسبوعي هو مرة واحدة فقط*
*ملاحظة‼️ مستوى الاشياء: مستحيل > اسطوري > نادر*

*˼‏˹↫𝑽 𝑰 𝑷⊰☀⊱𝑺 𝑻 𝑶 𝑹 𝑬*

*〄━═─⧉━⌬〔☀️〕⌬━⧉─═━〄*
*˼‏˹↫الشمس⊰☀⊱𝑺.𝑼.𝑵*`;

      // إرسال النص فقط
      await reply(form);

    } catch (err) {
      console.error(err);
      reply(`⚠️ حدث خطأ أثناء تنفيذ الأمر:\n${err.message}`);
    }
  }
};
