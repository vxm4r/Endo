// ملف: plugins/شات.js (فتح/قفل دردشة المجموعة)

export default {
  name: "شات",
  aliases: ["chat", "جروب"],
  description: "فتح/قفل دردشة المجموعة",
  category: "admin",

  group: true,
  botAdmin: true,

  async run({ sock, message, reply, args, isDeveloper }) {
    const mode = (args[0] || "").toLowerCase();

    // استخراج بيانات المجموعة + المرسل
    let metadata;
    try {
      metadata = await sock.groupMetadata(message.key.remoteJid);
    } catch {
      return reply("⚠️ تعذر الوصول لمعلومات المجموعة. حاول لاحقًا.");
    }

    const senderId = message.key.participant;
    const sender = metadata.participants.find(p => p.id === senderId);
    const isAdmin = sender?.admin === 'admin' || sender?.admin === 'superadmin';

    // تفويض الصلاحيات
    if (!isAdmin && !isDeveloper) {
      return reply("🚫 صلاحياتك غير كافية لتنفيذ هذه العملية.");
    }

    // خيارات مسموحة
    const lockModes = ["قفل", "close", "lock"];
    const openModes = ["فتح", "open", "unlock"];

    try {
      if (lockModes.includes(mode)) {
        await sock.groupSettingUpdate(message.key.remoteJid, 'announcement');
        return reply("🔒 **الدردشة مقفولة.** فقط المشرفين يمكنهم الإرسال.");
      }

      if (openModes.includes(mode)) {
        await sock.groupSettingUpdate(message.key.remoteJid, 'not_announcement');
        return reply("🔓 **الدردشة مفتوحة.** الجميع يمكنهم المشاركة الآن.");
      }

      // رسالة مساعدة
      return reply(`
📌 **طريقة الاستخدام:**
• \`.شات قفل\` = 🔒 قفل الدردشة
• \`.شات فتح\` = 🔓 فتح الدردشة
      `.trim());

    } catch (err) {
      console.error(err);
      return reply("⚠️ خطأ فني غير متوقع. فريق التطوير يعالج الموضوع 🔧");
    }
  }
};