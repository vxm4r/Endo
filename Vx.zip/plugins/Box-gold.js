import fs from "fs-extra";
import path from "path";

// الدالة لاختيار n عناصر مختلفة عشوائياً حسب الاحتمالات
function getRandomUnique(items, n) {
    const selected = [];
    const copy = [...items]; // نسخة لتجنب تعديل الأصلي

    while (selected.length < n && copy.length > 0) {
        const total = copy.reduce((sum, i) => sum + i.chance, 0);
        let r = Math.random() * total;

        for (let i = 0; i < copy.length; i++) {
            if (r < copy[i].chance) {
                selected.push(copy[i].name);
                copy.splice(i, 1); // إزالة العنصر لتجنب التكرار
                break;
            }
            r -= copy[i].chance;
        }

    }

    return selected;
}

export default {
    name: "ذهبي",
    description: "صندوق الحظ الذهبي مع اختيار 3 أو 4 اشياء عشوائية بدون تكرار",
    async run({ reply }) {
        try {
            // **تغيير مسار الملف إلى Golden.json**
            const dataPath = path.join(process.cwd(), "data", "Golden.json");
            const allItems = await fs.readJSON(dataPath); // JSON يحتوي على {name, chance}

            // **اختيار عدد العناصر بين 3 و 4**
            const itemsToSelect = Math.floor(Math.random() * 2) + 3; // يختار إما 3 أو 4
            const chosen = getRandomUnique(allItems, itemsToSelect);

            const itemsText = chosen.map(i => `• ${i}`).join("\n");

            // **تعديل نموذج الرد ليناسب الصندوق الذهبي**
            const form = `

˼‏˹↫𝑽 𝑰 𝑷⊰☀⊱𝑺 𝑻 𝑶 𝑹 𝑬

╔⟐━─⧉━⌬〔☀️〕⌬━⧉─━⟐╗

تعلن ادارة
˼‏˹↫الشمس⊰☀⊱𝑺.𝑼.𝑵

⟐━─⧉━〘 صندوق الحظ 〙━⧉─━⟐

❀ النوع:『ذهبي』
❀ الوصف:『الحصول على 3 او 4 اشياء اسطورية مع احتمال 25% الحصول على اشياء نادرة او مستحيلة』
❀ المشـ✨ـتري:『』
❀ الاشـ📦ـياء:『${itemsText}』
❀ السـ💎ـعر:『2M』
❀ المسـ👤ـؤول:『』

ملاحظة‼️ مرة واحدة هو الحد الاسبوعي للصندوق الذهبي يتم تسجيله في البنك
ملاحظة‼️ مستوى الاشياء: مستحيل > اسطوري > نادر > غير عادي > عادي

˼‏˹↫𝑽 𝑰 𝑷⊰☀⊱𝑺 𝑻 𝑶 𝑹 𝑬

〄━═─⧉━⌬〔☀️〕⌬━⧉─═━〄
˼‏˹↫الشمس⊰☀⊱𝑺.𝑼.𝑵
`;

            await reply(form);

        } catch (err) {
            console.error(err);
            reply("⚠️ حصل خطأ أثناء قراءة ملف الأشياء (Golden.json).");
        }

    }
};