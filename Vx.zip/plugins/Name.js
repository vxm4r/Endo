// ملف: plugins/اسم.js (معدل للمشرفين والمطورين)

export default {
    name: "اسم",
    description: "تغيير اسم المجموعة.",
    category: "admin",

    // الصلاحيات الأساسية
    group: true, // يعمل في المجموعات فقط

    async run({ sock, message, reply, text, isDeveloper }) {
        // --- التحقق من الصلاحيات (مشرف أو مطور) ---
        const metadata = await sock.groupMetadata(message.key.remoteJid);
        const sender = metadata.participants.find(p => p.id === message.key.participant);
        const isAdmin = sender?.admin === 'admin' || sender?.admin === 'superadmin';

        if (!isAdmin && !isDeveloper) {
            return reply("❌ هذا الأمر للمشرفين والمطور فقط.");
        }

        try {
            // 1. التحقق من وجود نص (الاسم الجديد)
            if (!text) {
                return reply("❌ *خطأ:* يرجى كتابة الاسم الجديد للمجموعة بعد الأمر.\n\n*مثال:*\n.اسم المجموعة الجديدة");
            }

            // 2. التحقق من طول الاسم (واتساب يسمح بـ 100 حرف كحد أقصى)
            if (text.length > 100) {
                return reply("❌ *خطأ:* اسم المجموعة طويل جدًا. الحد الأقصى 100 حرف.");
            }

            // 3. استدعاء دالة Baileys الرسمية لتغيير الاسم
            await sock.groupUpdateSubject(message.key.remoteJid, text);

            // 4. إرسال رسالة نجاح
            await reply(`✅ تم تغيير اسم المجموعة إلى:\n*${text}*`);

        } catch (error) {
            console.error("Error in 'اسم' command:", error);
            await reply(`❌ *حدث خطأ أثناء تغيير اسم المجموعة:*\n${error.message}`);
        }
    }
};