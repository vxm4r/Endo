import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';

const ROOT = process.cwd();

export default {
  name: "files",
  description: "Advanced File Management System (List/Open/View/Add/Delete/Edit/Rename/Create/Update)",
  usage: ".files [list|open|view|add|del|rename|mkdir|update] ...",
  developer: true,
  async run({ message, reply, args, handler, downloadMedia, sock }) {
    try {
      const sub = (args && args[0]) ? args[0].toLowerCase() : 'list';
      const jid = message.key.remoteJid;

      // ----- Helper Functions ----- //
      const safeStat = async (p) => {
        try { return await fsp.stat(p); } catch { return null; }
      };

      // Resolve a single index from root
      async function resolveIndex(num) {
        const names = await fsp.readdir(ROOT, { withFileTypes: true });
        const idx = parseInt(num) - 1;
        if (isNaN(idx) || idx < 0 || idx >= names.length) return null;
        const entry = names[idx];
        return { 
            path: path.join(ROOT, entry.name), 
            name: entry.name, 
            isDir: entry.isDirectory() 
        };
      }

      // Resolve compound path like "3/2" (Folder 3, File 2)
      async function resolveCompound(arg) {
        const parts = String(arg).split('/');
        if (parts.length === 1) return await resolveIndex(parts[0]);
        
        const folder = await resolveIndex(parts[0]);
        if (!folder || !folder.isDir) return null;

        const names = await fsp.readdir(folder.path, { withFileTypes: true });
        const idx = parseInt(parts[1]) - 1;
        if (isNaN(idx) || idx < 0 || idx >= names.length) return null;
        
        const entry = names[idx];
        return { 
            path: path.join(folder.path, entry.name), 
            name: entry.name, 
            isDir: entry.isDirectory(),
            parent: folder.path 
        };
      }

      // ----- Actions ----- //
      switch (sub) {
        case 'list': {
          const names = await fsp.readdir(ROOT, { withFileTypes: true });
          let out = `📂 *Root Directory:* \`${ROOT}\`\n\n`;
          names.forEach((n, i) => {
            out += `${i + 1}. ${n.isDirectory() ? '📁' : '📄'} ${n.name}\n`;
          });
          out += `\n*Commands:* \`open <#>\`, \`view <#/#>\`, \`add <#> <name>\`, \`del <#>\`, \`rename <#> <new_name>\`, \`mkdir <name>\`, \`update\``;
          return reply(out);
        }

        case 'open': {
          const num = args[1];
          const folder = await resolveIndex(num);
          if (!folder || !folder.isDir) return reply("❌ Invalid folder index.");
          
          const names = await fsp.readdir(folder.path, { withFileTypes: true });
          let out = `📂 *Contents of ${folder.name}:*\n\n`;
          names.forEach((n, i) => {
            out += `${i + 1}. ${n.isDirectory() ? '📁' : '📄'} ${n.name}\n`;
          });
          out += `\n*Tip:* Use \`view ${num}/<#>\` to see a file.`;
          return reply(out);
        }

        case 'view': {
          const spec = args[1];
          const file = await resolveCompound(spec);
          if (!file) return reply("❌ File/Folder not found.");
          if (file.isDir) return reply(`❌ "${file.name}" is a directory. Use "open" instead.`);

          const ext = path.extname(file.name).toLowerCase();
          const isText = ['.js', '.json', '.txt', '.md', '.html', '.css', '.json5', '.ts'].includes(ext);

          if (isText) {
            const content = await fsp.readFile(file.path, 'utf8');
            return reply(`📄 *File:* ${file.name}\n\n\`\`\`${ext.replace('.','')}\n${content.slice(0, 4000)}\n\`\`\``);
          } else {
            await sock.sendMessage(jid, { document: { url: file.path }, fileName: file.name, mimetype: 'application/octet-stream' }, { quoted: message });
            return reply(`✅ Sent binary file: ${file.name}`);
          }
        }

        case 'add': {
          const folderIdx = args[1];
          const fileName = args[2];
          if (!folderIdx || !fileName) return reply("❌ Usage: `.files add <folder_#> <filename>`");
          
          const folder = await resolveIndex(folderIdx);
          if (!folder || !folder.isDir) return reply("❌ Invalid folder destination.");

          const filePath = path.join(folder.path, fileName);
          const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
          
          let content = "";
          if (quoted) {
            content = quoted.conversation || quoted.extendedTextMessage?.text;
            if (!content) {
                const buffer = await downloadMedia(message);
                if (buffer) {
                    await fsp.writeFile(filePath, buffer);
                    return reply(`✅ Saved media as *${fileName}* in *${folder.name}*`);
                }
            }
          }

          await fsp.writeFile(filePath, content || '', 'utf8');
          return reply(`✅ Created file *${fileName}* in *${folder.name}*`);
        }

        case 'edit': {
          const file = await resolveCompound(args[1]);
          if (!file || file.isDir) return reply("❌ Target must be a file.");

          const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
          if (!quoted) return reply("❌ Please reply to a message with the new content.");

          let content = quoted.conversation || quoted.extendedTextMessage?.text;
          if (content) {
            await fsp.writeFile(file.path, content, 'utf8');
          } else {
            const buffer = await downloadMedia(message);
            if (!buffer) return reply("❌ Could not download media for edit.");
            await fsp.writeFile(file.path, buffer);
          }
          return reply(`✅ Updated *${file.name}* successfully.`);
        }

        case 'del': {
          const item = await resolveCompound(args[1]);
          if (!item) return reply("❌ Item not found.");
          
          await fsp.rm(item.path, { recursive: true, force: true });
          return reply(`🗑️ Deleted: *${item.name}*`);
        }

        case 'rename': {
          const item = await resolveCompound(args[1]);
          const newName = args.slice(2).join(' ');
          if (!item || !newName) return reply("❌ Usage: `.files rename <#> <new_name>`");

          const newPath = path.join(path.dirname(item.path), newName);
          await fsp.rename(item.path, newPath);
          return reply(`✏️ Renamed to: *${newName}*`);
        }

        case 'mkdir': {
          const name = args.slice(1).join('_');
          if (!name) return reply("❌ Provide a folder name.");
          const p = path.join(ROOT, name);
          await fsp.mkdir(p, { recursive: true });
          return reply(`📁 Created directory: *${name}*`);
        }

        case 'update': {
          if (handler && typeof handler.reloadAllPlugins === 'function') {
            await handler.reloadAllPlugins();
            return reply("🔄 All plugins reloaded successfully.");
          }
          return reply("⚠️ Reload function not found in handler.");
        }

        default:
          return reply("❓ Unknown command. Use: `list, open, view, add, edit, del, rename, mkdir, update`.");
      }
    } catch (err) {
      console.error(err);
      return reply(`❌ Error: ${err.message}`);
    }
  }
};
