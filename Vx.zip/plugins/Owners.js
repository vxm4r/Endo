
import fs from 'fs/promises';
import path from 'path';

// المسار الكامل لملف الكونفج
const configPath = path.resolve(process.cwd(), 'config.js');

// دوال قراءة وكتابة الكونفج (تبقى كما هي)
async function readConfig() {
    try {
        const { config } = await import(`file://${configPath}?v=${Date.now()}`);
        return config;
    } catch (error) {
        console.error('خطأ في قراءة ملف الكونفج:', error);
        return null;
    }
}
async function writeConfig(newConfig) {
    try {
        const fileContent = await fs.readFile(configPath, 'utf8');
        const newDevelopersArrayString = JSON.stringify(newConfig.DEVELOPERS, null, 4);
        const updatedContent = fileContent.replace(
            /DEVELOPERS\s*:\s*\[[^\]]*\]/,
            `DEVELOPERS: ${newDevelopersArrayString}`
        );
        await fs.writeFile(configPath, updatedContent, 'utf8');
        return true;
    } catch (error) {
        console.error('خطأ في كتابة ملف الكونفج:', error);
        return false;
    }
}

export default {
    name: "مطور",
    aliases: ["المطور"],
    description: "إدارة قائمة مطوري البوت (إضافة، حذف، عرض).",
    category: "developer",
    
    developer: true, 
    group: true,

    async run({ m, args, reply, sock }) {
        const subCommand = args[0]?.toLowerCase();

        if (!subCommand) {
            const helpMessage = `
*╔═════ 「 إدارة المطورين 」 ═════╗*
*║*
*║ 📋 *.مطور عرض*
*║*    (لعرض قائمة المطورين الحاليين)
*║*
*║ ➕ *.مطور اضف*
*║*    (لإضافة مطور جديد بالرد أو المنشن)
*║*
*║ ➖ *.مطور حذف*
*║*    (لحذف مطور بالرد أو المنشن أو الرقم)
*║*
*╚══════════════════════╝*
            `;
            return reply(helpMessage.trim());
        }

        const contextInfo = m.message?.extendedTextMessage?.contextInfo;
        const quotedSender = contextInfo?.participant;
        const mentionedJid = contextInfo?.mentionedJid || [];

        // ✨✨ [الحل النهائي الحقيقي باستخراج البيانات الخام] ✨✨
        const getRealIdsFromMetadata = async (targetId) => {
            try {
                const metadata = await sock.groupMetadata(m.key.remoteJid);
                const participant = metadata.participants.find(p => p.id === targetId);
                
                if (!participant) return null;

                // 1. الـ JID الحقيقي هو phoneNumber
                const realJid = participant.phoneNumber;

                // 2. الـ LID الحقيقي هو id، فقط إذا كان ينتهي بـ @lid
                const realLid = participant.id.endsWith('@lid') ? participant.id : null;

                // إذا لم نجد JID حقيقي، نستخدم خطة بديلة
                if (!realJid) {
                    const cleanNum = targetId.split('@')[0].split(':')[0];
                    return { jid: `${cleanNum}@s.whatsapp.net`, lid: realLid };
                }
                
                return { jid: realJid, lid: realLid };

            } catch (e) {
                console.error("فشل في الحصول على بيانات المجموعة:", e);
                return null;
            }
        };

        switch (subCommand) {
            case "عرض": {
                // ... (لا تغيير هنا)
                const config = await readConfig();
                if (!config) return reply('حدث خطأ أثناء قراءة الإعدادات.');
                const developers = config.DEVELOPERS.filter(jid => jid.endsWith('@s.whatsapp.net')).map(jid => jid.split('@')[0]);
                if (developers.length === 0) return reply('ℹ️ لا يوجد مطورون في القائمة حاليًا.');
                let response = '📋 *قائمة المطورين الحاليين:*\n\n';
                developers.forEach((dev, index) => { response += `${index + 1}. wa.me/${dev}\n`; });
                return reply(response.trim());
            }

            case "اضف": {
                const targetId = quotedSender || (mentionedJid.length > 0 ? mentionedJid[0] : null);
                if (!targetId) {
                    return reply('⚠️ يجب عليك الرد على رسالة شخص أو عمل منشن له.');
                }

                const userInfo = await getRealIdsFromMetadata(targetId);
                if (!userInfo) {
                    return reply('❌ لم أتمكن من العثور على معلومات هذا المستخدم في المجموعة.');
                }

                const config = await readConfig();
                if (!config) return reply('حدث خطأ أثناء قراءة الإعدادات.');

                const { jid, lid } = userInfo;
                const idsToAdd = [jid, lid].filter(Boolean); // فلترة القيم الفارغة (null)

                if (idsToAdd.some(id => config.DEVELOPERS.includes(id))) {
                    return reply('✅ هذا المستخدم هو مطور بالفعل.');
                }

                config.DEVELOPERS.push(...idsToAdd);

                const success = await writeConfig(config);
                if (success) {
                    let successMsg = `🎉 تم إضافة المستخدم *@${jid.split('@')[0]}* إلى قائمة المطورين بنجاح.\n`;
                    successMsg += `*JID المضاف:* \`${jid}\`\n`;
                    if (lid) {
                        successMsg += `*LID المضاف:* \`${lid}\``;
                    } else {
                        successMsg += `*LID:* (غير متوفر لهذا المستخدم حاليًا)`;
                    }
                    reply(successMsg, { mentions: [targetId] });
                } else {
                    reply('❌ فشلت عملية تحديث ملف الإعدادات.');
                }
                break;
            }

            case "حذف": {
                // ... (المنطق هنا يحتاج أيضًا للتحديث ليكون متوافقًا)
                const config = await readConfig();
                if (!config) return reply('حدث خطأ أثناء قراءة الإعدادات.');

                let targetId;
                const developers = config.DEVELOPERS.filter(j => j.endsWith('@s.whatsapp.net'));
                const textArg = args[1];

                if (quotedSender || mentionedJid.length > 0) {
                    targetId = quotedSender || mentionedJid[0];
                } else if (textArg && !isNaN(textArg)) {
                    const index = parseInt(textArg, 10) - 1;
                    if (index >= 0 && index < developers.length) {
                        targetId = developers[index];
                    } else {
                        return reply('❌ الرقم الذي أدخلته غير صالح.');
                    }
                } else {
                    return reply('⚠️ للحذف، قم بالرد، أو عمل منشن، أو اكتب رقم المطور من القائمة.');
                }

                if (!targetId) return reply('❌ لم أتمكن من تحديد المستخدم.');
                
                const userInfo = await getRealIdsFromMetadata(targetId);
                if (!userInfo) {
                    return reply('❌ لم أتمكن من العثور على معلومات هذا المستخدم في المجموعة.');
                }

                const { jid: jidToDelete, lid: lidToDelete } = userInfo;
                const idsToDelete = [jidToDelete, lidToDelete].filter(Boolean);

                if (!idsToDelete.some(id => config.DEVELOPERS.includes(id))) {
                    return reply('ℹ️ هذا المستخدم ليس مطورًا أصلاً.');
                }

                config.DEVELOPERS = config.DEVELOPERS.filter(dev => !idsToDelete.includes(dev));
                
                const success = await writeConfig(config);
                if (success) {
                    reply(`🗑️ تم حذف المستخدم *@${jidToDelete.split('@')[0]}* من قائمة المطورين.`, {
                        mentions: [targetId]
                    });
                } else {
                    reply('❌ فشلت عملية تحديث ملف الإعدادات.');
                }
                break;
            }

            default:
                reply(`❌ الأمر الفرعي "${subCommand}" غير معروف. اكتب *.مطور* لعرض قائمة المساعدة.`);
                break;
        }
    }
};