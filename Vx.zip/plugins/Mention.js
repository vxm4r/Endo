export default {
    name: "منشن",
    description: "عمل منشن لجميع أعضاء المجموعة برسالة.",
    
    category: "admin",

    // الصلاحيات المطلوبة
    group: true,
    admin: true,

    async run({ sock, message, reply, text, args, isDeveloper }) {
    
      const metadata = await sock.groupMetadata(message.key.remoteJid);
        const sender = metadata.participants.find(p => p.id === message.key.participant);
        const isAdmin = sender?.admin === 'admin' || sender?.admin === 'superadmin';

        if (!isAdmin && !isDeveloper) {
            return reply("❌ هذا الأمر للمشرفين والمطور فقط.");
        }
        try {
            // 1. الحصول على بيانات المجموعة (metadata)
            const metadata = await sock.groupMetadata(message.key.remoteJid);
            if (!metadata) {
                return reply("❌ لا يمكن الحصول على بيانات المجموعة.");
            }

            // 2. استخراج قائمة المشاركين (الأعضاء)
            const participants = metadata.participants.map(p => p.id);
            if (!participants || participants.length === 0) {
                return reply("❌ لا يمكن الحصول على قائمة أعضاء المجموعة.");
            }

            // 3. تحديد النص الذي سيتم إرساله
            let messageText = "";
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;

            if (text) {
                // الحالة الأولى: المستخدم كتب نصًا بعد الأمر
                messageText = text;
            } else if (quoted) {
                // الحالة الثانية: المستخدم رد على رسالة
                // نحاول الحصول على النص من أي نوع رسالة مقتبسة
                messageText = quoted.conversation || 
                              quoted.extendedTextMessage?.text || 
                              quoted.imageMessage?.caption || 
                              quoted.videoMessage?.caption || 
                              ""; // نص فارغ إذا لم نجد شيئًا
            } else {
                // إذا لم يكتب نصًا ولم يرد على رسالة
                return reply("💡 *طريقة الاستخدام:*\n1. اكتب `.منشن رسالتك هنا`\n2. أو قم بالرد على رسالة واكتب `.منشن`");
            }
            
            // إذا كان النص فارغًا بعد كل المحاولات، نضع رسالة افتراضية
            if (!messageText.trim()) {
                messageText = "📢 تنبيه للجميع!";
            }

            // 4. ✨ إرسال الرسالة مع المنشن الخفي ✨
            await sock.sendMessage(message.key.remoteJid, {
                text: messageText,
                mentions: participants // هذا هو الجزء السحري الذي يقوم بالمنشن الخفي
            });

        } catch (error) {
            console.error("Error in 'منشن' command:", error);
            await reply(`❌ *حدث خطأ أثناء عمل المنشن:*\n${error.message}`);
        }
    }
};