// ملف: plugins/خش.js

export default {
    name: "خش",
    aliases: ["انضم", "ادخل"],
    description: "يجعل البوت ينضم إلى مجموعة باستخدام رابط الدعوة.",
    category: "developer", // هذا الأمر يجب أن يكون للمطور فقط
    developer: true, // ✨ تفعيل صلاحيات المطور فقط

    async run({ reply, message, args, sock, handler }) {
        const text = args.join(' ');

        // 1. التحقق من وجود رابط
        if (!text) {
            return reply("✋ يرجى إرسال رابط المجموعة مع الأمر.\n\n*مثال:*\n.خش https://chat.whatsapp.com/...");
        }

        // 2. استخراج كود الدعوة من الرابط باستخدام Regex
        const linkRegex = /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/;
        const match = text.match(linkRegex);

        if (!match || !match[1]) {
            return reply("❌ الرابط الذي أرسلته غير صالح أو لا يحتوي على كود دعوة.");
        }
        const code = match[1];

        // 3. إعلام المستخدم بالبدء
        await reply(`🚀 جاري محاولة الانضمام إلى المجموعة...`);

        try {
            // 4. ✨ الدالة الأساسية: قبول الدعوة ✨
            const groupJid = await sock.groupAcceptInvite(code);

            // 5. إرسال رسالة تأكيد في الخاص
            await reply(`✅ تم الانضمام بنجاح إلى المجموعة!\n\n*ID:* ${groupJid}`);

            // 6. إرسال رسالة ترحيب في المجموعة الجديدة
            const welcomeMessage = `
*أهلاً بالجميع!* 👋

أنا ${sock.user.name}، بوت واتساب.
تمت دعوتي بواسطة @${handler.getUserJid(message).split('@')[0]}.

يمكنكم استخدام الأمر *.اوامر* لمعرفة ما يمكنني فعله.
            `;

            // تأخير بسيط قبل إرسال الرسالة في المجموعة الجديدة
            await new Promise(resolve => setTimeout(resolve, 2000));

            await sock.sendMessage(groupJid, {
                text: welcomeMessage.trim(),
                // عمل منشن للشخص الذي أضاف البوت
                mentions: [handler.getUserJid(message)]
            });

        } catch (error) {
            // إرسال رسالة خطأ مفصلة
            await reply(`عملت طلب غور اقبل`);
        }
    }
};