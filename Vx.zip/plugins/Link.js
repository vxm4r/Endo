// ملف: plugins/لينك.js

export default {
    name: "لينك",
    
    description: "يرسل رابط الدعوة للمجموعة الحالية.",
    category: "group",
    
    // --- الصلاحيات المطلوبة ---
    group: true, // يجب أن يكون في مجموعة

    async run({ sock, message, reply }) {
        try {
            const groupJid = message.key.remoteJid;

            // --- [الخطوة 1] التحقق مما إذا كان البوت مشرفًا ---
            // هذه هي الطريقة الأكثر موثوقية التي اكتشفناها
            const metadata = await sock.groupMetadata(groupJid);
            const cleanBotId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
            const selfParticipant = metadata.participants.find(p => p.phoneNumber === cleanBotId);
            
            if (!selfParticipant || !selfParticipant.admin) {
                return reply("❌ لا يمكنني إنشاء رابط دعوة لأنني لست مشرفًا في هذه المجموعة.");
            }

            // --- [الخطوة 2] جلب كود الدعوة ---
            const inviteCode = await sock.groupInviteCode(groupJid);
            const inviteLink = `https://chat.whatsapp.com/${inviteCode}`;

            // --- [الخطوة 3] إرسال الرابط ---
            const responseText = `✅ *تفضل، هذا هو رابط المجموعة:*\n\n${inviteLink}`;
            await reply(responseText);

        } catch (error) {
            console.error("Error in 'لينك' command:", error);
            await reply(`❌ حدث خطأ أثناء جلب الرابط: ${error.message}`);
        }
    }
};