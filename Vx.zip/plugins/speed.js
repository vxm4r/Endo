export default {
  name: "سرعه",
  command: ["سرعة", "ping"],
  description: "يعرض سرعة استجابة البوت بالمللي ثانية",
  category: "TOOLS",

  async run({ sock, message, reply }) {
    const start = Date.now();
    const temp = await reply("⚡ *𝐕𝐗 BOT — Checking Speed...*");
    const latency = Date.now() - start;

    await sock.sendMessage(
      message.key.remoteJid,
      { text: `🚀 *𝐕𝐗 SPEED TEST*\n\n⏱️ *${latency} ms*\n\n🤖 𝐕𝐗 𝐁𝐎𝐓 ⚡` },
      { edit: temp.key }
    );
  }
};