import axios from 'axios';
import fs from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';

export default {
    name: "تيكتوك",
    desc: "يحمل فيديوهات من تيك توك بدون علامة مائية",
    category: "وسائط",
    usage: "/تيكتوك [رابط] أو بالرد على رابط",

    async run({ bot, message, args }) {
        // التحقق من وجود رابط
        const text = args.length > 0 ? args.join(' ') 
            : message.message?.extendedTextMessage?.contextInfo?.quotedMessage?.conversation;

        if (!text) {
            return await bot.sendMessage(message.key.remoteJid, {
                text: "⚠️ يرجى إرسال رابط فيديو تيك توك\nمثال:\n/tiktok https://vm.tiktok.com/xxxxx"
            });
        }

        // استخراج الرابط من النص
        const urlMatch = text.match(/(https?:\/\/[^\s]+)/);
        if (!urlMatch) {
            return await bot.sendMessage(message.key.remoteJid, {
                text: "❌ لم يتم العثور على رابط صحيح في الرسالة"
            });
        }

        const tiktokUrl = urlMatch[0];
        
        await bot.sendMessage(message.key.remoteJid, { 
            text: "⏳ جارٍ تحميل الفيديو من تيك توك..." 
        });

        try {
            // استخدام API لتحميل الفيديو
            const apiUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(tiktokUrl)}`;
            
            const response = await axios.get(apiUrl, {
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });

            if (response.data.code !== 0) {
                throw new Error('فشل في استخراج الفيديو');
            }

            const videoData = response.data.data;

            // تحميل الفيديو
            const videoResponse = await axios.get(videoData.play, {
                responseType: 'arraybuffer',
                timeout: 60000
            });

            const tempFile = join(tmpdir(), `tiktok_${Date.now()}.mp4`);
            await fs.writeFile(tempFile, videoResponse.data);

            // إرسال الفيديو
            await bot.sendMessage(message.key.remoteJid, {
                video: { url: tempFile },
                caption: `🎵 ${videoData.title || 'فيديو تيك توك'}\n\nبواسطة: ${videoData.author?.nickname || 'مستخدم تيك توك'}`,
                gifPlayback: false
            });

            // تنظيف الملف المؤقت
            await fs.unlink(tempFile);

        } catch (error) {
            console.error('❌ خطأ في تحميل تيك توك:', error);
            
            let errorMsg = "❌ فشل تحميل الفيديو";
            
            if (error.code === 'ECONNABORTED') {
                errorMsg += "\n⏰ انتهت مهلة الطلب";
            } else if (error.response?.status === 404) {
                errorMsg += "\n🔍 الرابط غير صحيح أو الفيديو محذوف";
            } else {
                errorMsg += `\n📱 الخطأ: ${error.message}`;
            }

            await bot.sendMessage(message.key.remoteJid, { text: errorMsg });
        }
    }
};