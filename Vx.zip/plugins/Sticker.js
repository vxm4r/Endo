import { downloadContentFromMessage } from "@whiskeysockets/baileys";
import webpmux from "node-webpmux";
import ffmpeg from 'fluent-ffmpeg';
import fs from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';

// وظيفة معالجة الميديا (صور أو فيديو) وتحويلها لـ WebP
async function mediaToWebp(media, type) {
    const tmpFileIn = join(tmpdir(), `${Date.now()}.${type === 'image' ? 'jpg' : 'mp4'}`);
    const tmpFileOut = join(tmpdir(), `${Date.now()}.webp`);

    await fs.writeFile(tmpFileIn, media);

    return new Promise((resolve, reject) => {
        const ff = ffmpeg(tmpFileIn);
        
        // إعدادات خاصة للملصقات المتحركة أو العادية لضمان الحجم والجودة
        const options = [
            "-vcodec", "libwebp",
            "-vf", "scale='min(512,iw)':'min(512,ih)':force_original_aspect_ratio=decrease,fps=15, pad=512:512:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse"
        ];

        if (type === 'video') {
            ff.inputOptions(['-t', '8']); // تحديد مدة الملصق بـ 8 ثواني كحد أقصى
        }

        ff.on('error', async (err) => {
            console.error('FFMPEG Error:', err);
            await fs.unlink(tmpFileIn).catch(() => {});
            reject(err);
        })
        .on('end', async () => {
            try {
                const webpBuffer = await fs.readFile(tmpFileOut);
                await fs.unlink(tmpFileIn).catch(() => {});
                await fs.unlink(tmpFileOut).catch(() => {});
                resolve(webpBuffer);
            } catch (error) {
                reject(error);
            }
        })
        .addOutputOptions(options)
        .toFormat("webp")
        .save(tmpFileOut);
    });
}

export default {
    name: "ملصق",
    desc: "يحول الصور والفيديوهات إلى ملصق مع حقوق",
    category: "tools",
    usage: "/ملصق (بالرد على صورة أو فيديو قصير)",
    
    async run({ bot, message, args }) {
        // التحقق مما إذا كان الرد على صورة أو فيديو
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const isImage = quoted?.imageMessage;
        const isVideo = quoted?.videoMessage;

        if (!isImage && !isVideo) {
            return await bot.sendMessage(message.key.remoteJid, {
                text: "⚠️ يرجى الرد على صورة أو فيديو قصير لتحويله إلى ملصق."
            });
        }

        await bot.sendMessage(message.key.remoteJid, { text: "⏳ جارٍ إنشاء الملصق..." });

        try {
            const mediaType = isImage ? 'image' : 'video';
            const stream = await downloadContentFromMessage(
                isImage || isVideo,
                mediaType
            );

            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            // تحويل الميديا إلى WebP (سواء كانت ثابتة أو متحركة)
            const webpBuffer = await mediaToWebp(buffer, mediaType);
            
            // إضافة حقوق الـ EXIF
            const img = new webpmux.Image();
            await img.load(webpBuffer);

            const exifData = {
                "sticker-pack-id": "king-solo-bot-v1.0",
                "sticker-pack-name": "𝐕𝐗",
                "sticker-pack-publisher": "𝐕𝐈𝐏🐦‍🔥𝐒𝐔𝐍",
                "emojis": ["🍁"],
            };
            
            const exif = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
            const jsonBuffer = Buffer.from(JSON.stringify(exifData), "utf-8");
            const exiffinal = Buffer.concat([exif, jsonBuffer]);
            exiffinal.writeUIntLE(jsonBuffer.length, 14, 4);
            img.exif = exiffinal;

            await bot.sendMessage(message.key.remoteJid, {
                sticker: await img.save(null)
            });

        } catch (error) {
            console.error("❌ حدث خطأ في أمر ملصق:", error);
            await bot.sendMessage(message.key.remoteJid, {
                text: `❌ حدث خطأ ما أثناء إنشاء الملصق.\n\n*السبب:* تأكد أن الفيديو ليس طويلاً جداً.`
            });
        }
    }
};
