import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { exec } from 'child_process';
import { writeFile, unlink } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';

export default {
    name: "tomp3",
    desc: "تحويل الفيديو إلى ملف صوتي (MP3)",
    aliases: ["لصوت", "mp3"],
    category: "tools",
    
    async run({ bot, message }) {
        // ✨✨ تطبيق النمط الناجح: تعريف دالة reply محلية ✨✨
        const reply = (text) => {
            return bot.sendMessage(message.key.remoteJid, { text }, { quoted: message });
        };

        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quoted) {
            return reply("⚠️ *يرجى الرد على رسالة فيديو لتحويلها.*");
        }

        const videoMessage = quoted.videoMessage;
        if (!videoMessage) {
            return reply("❌ *الرسالة التي قمت بالرد عليها ليست فيديو.*");
        }

        await reply("📥 *جاري تحميل الفيديو...*");

        try {
            const stream = await downloadContentFromMessage(videoMessage, 'video');
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            const tempVideoPath = join(tmpdir(), `${Date.now()}.mp4`);
            const tempAudioPath = join(tmpdir(), `${Date.now()}.mp3`);

            await writeFile(tempVideoPath, buffer);

            await reply("🔄 *جاري تحويل الفيديو إلى صوت...*");

            exec(`ffmpeg -i "${tempVideoPath}" -q:a 0 -map a "${tempAudioPath}"`, async (error) => {
                // حذف ملف الفيديو المؤقت فورًا بعد التحويل
                await unlink(tempVideoPath).catch(e => console.error("Failed to delete temp video:", e));

                if (error) {
                    console.error("FFMPEG Error:", error);
                    await reply("❌ *حدث خطأ أثناء عملية التحويل.*");
                    return;
                }

                // ✨✨ إرسال الملف الصوتي باستخدام bot.sendMessage مباشرة ✨✨
                await bot.sendMessage(message.key.remoteJid, {
                    audio: { url: tempAudioPath },
                    mimetype: 'audio/mpeg',
                    ptt: false
                }, { quoted: message });

                // حذف ملف الصوت المؤقت بعد الإرسال
                await unlink(tempAudioPath).catch(e => console.error("Failed to delete temp audio:", e));
            });

        } catch (e) {
            console.error("Error in tomp3 command:", e);
            await reply("❌ *فشل تحميل الفيديو أو معالجته.*");
        }
    }
};
