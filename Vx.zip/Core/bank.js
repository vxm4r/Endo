// core/bank.js (ESM)
import fs from "fs";
import path from "path";

const DATA_DIR = path.join(process.cwd(), "data");
const DB_FILE = path.join(DATA_DIR, "bank.json");

// Create directory + file if missing
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE))
  fs.writeFileSync(DB_FILE, JSON.stringify({ players: {} }, null, 2));

// Basic read/write
function readDB() {
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}
function writeDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), "utf8");
}

// Exported main functions
export function loadBank() {
  return readDB();
}
export function saveBank(db) {
  writeDB(db);
}

// Normalize title (handle weird spacing)
function normalizeTitle(title) {
  return String(title || "").trim();
}

// MAIN ensurePlayer (merging both your versions)
export function ensurePlayerByTitle(db, title) {
  title = normalizeTitle(title);
  if (!title) throw new Error("❌ لقب فارغ.");

  if (!db.players[title]) {
    db.players[title] = {
      title,
      cash: 0,
      bank: 0,
      items: [],
      diamonds: 0,
      lastDaily: 0,
      lastWeekly: 0,
      createdAt: Date.now(),
      rankScore: 0
    };
    saveBank(db);
  }

  return db.players[title];
}

// Classic getter
export function getPlayer(db, title) {
  title = normalizeTitle(title);
  return db.players[title] || null;
}

// Funds handling
export function getCash(db, title) {
  const p = getPlayer(db, title);
  return p ? p.cash : 0;
}

export function addCash(db, title, amount) {
  const p = ensurePlayerByTitle(db, title);
  p.cash += Number(amount);
  saveBank(db);
  return p.cash;
}

export function deductCash(db, title, amount) {
  const p = ensurePlayerByTitle(db, title);
  amount = Number(amount);
  if (p.cash < amount) throw new Error("رصيد غير كافٍ.");
  p.cash -= amount;
  saveBank(db);
  return p.cash;
}

// Bank account deposit/withdraw
export function deposit(db, title, amount) {
  const p = ensurePlayerByTitle(db, title);
  amount = Number(amount);
  if (p.cash < amount) throw new Error("كاش غير كافٍ للإيداع.");
  p.cash -= amount;
  p.bank += amount;
  saveBank(db);
  return p.bank;
}

export function withdraw(db, title, amount) {
  const p = ensurePlayerByTitle(db, title);
  amount = Number(amount);
  if (p.bank < amount) throw new Error("رصيد البنك غير كافٍ.");
  p.bank -= amount;
  p.cash += amount;
  saveBank(db);
  return p.cash;
}

// Items
export function addItem(db, title, item) {
  const p = ensurePlayerByTitle(db, title);
  p.items.push(item);
  saveBank(db);
  return p.items;
}

export function getItems(db, title) {
  const p = getPlayer(db, title);
  return p ? p.items : [];
}

// Diamonds
export function addDiamonds(db, title, amount) {
  const p = ensurePlayerByTitle(db, title);
  p.diamonds += Number(amount);
  saveBank(db);
  return p.diamonds;
}

export function getDiamonds(db, title) {
  const p = getPlayer(db, title);
  return p ? p.diamonds : 0;
}

// Transfer between players
export function transfer(db, fromTitle, toTitle, amount) {
  const sender = ensurePlayerByTitle(db, fromTitle);
  const receiver = ensurePlayerByTitle(db, toTitle);
  amount = Number(amount);

  if (sender.cash < amount) throw new Error("رصيد المرسل غير كافٍ.");

  sender.cash -= amount;
  receiver.cash += amount;
  saveBank(db);

  return { sender, receiver };
}

// Ranking
export function getRank(db, top = 10) {
  const players = Object.values(db.players)
    .sort((a, b) => b.cash - a.cash)
    .slice(0, top)
    .map((p, i) => ({ rank: i + 1, title: p.title, cash: p.cash }));

  return players;
}

// Daily / Weekly
const DAY = 86400000;
const WEEK = 7 * DAY;

export function claimDaily(db, title, amount = 100) {
  const p = ensurePlayerByTitle(db, title);
  const now = Date.now();

  if (now - p.lastDaily < DAY)
    throw new Error("تم أخذ اليومي، انتظر للغد.");

  p.lastDaily = now;
  p.cash += Number(amount);
  saveBank(db);
  return p.cash;
}

export function claimWeekly(db, title, amount = 1000) {
  const p = ensurePlayerByTitle(db, title);
  const now = Date.now();

  if (now - p.lastWeekly < WEEK)
    throw new Error("تم أخذ الأسبوعي مسبقاً.");

  p.lastWeekly = now;
  p.cash += Number(amount);
  saveBank(db);
  return p.cash;
}

// Wheel (lucky spin)
export function spinWheel(db, title) {
  const rewards = [
    { type: "cash", amount: 1000 },
    { type: "cash", amount: 5000 },
    { type: "diamonds", amount: 5 },
    { type: "item", name: "بطاقة نادرة" },
    { type: "cash", amount: 25000 },
    { type: "nothing" }
  ];

  const prize = rewards[Math.floor(Math.random() * rewards.length)];
  const p = ensurePlayerByTitle(db, title);

  if (prize.type === "cash") p.cash += prize.amount;
  if (prize.type === "diamonds") p.diamonds += prize.amount;
  if (prize.type === "item") p.items.push(prize.name);

  saveBank(db);
  return prize;
}

// Gambling
export function bet(db, title, amount) {
  const p = ensurePlayerByTitle(db, title);
  amount = Number(amount);

  if (p.cash < amount) throw new Error("رصيد غير كافٍ للرهان.");

  const win = Math.random() < 0.45;

  if (win) {
    const reward = Math.floor(amount * (1 + Math.random() * 1.5));
    p.cash += reward;
    saveBank(db);
    return { win: true, reward };
  } else {
    p.cash -= amount;
    saveBank(db);
    return { win: false, lost: amount };
  }
}

// Attack system
export function attack(db, attackerTitle, targetTitle, stake) {
  const a = ensurePlayerByTitle(db, attackerTitle);
  const t = ensurePlayerByTitle(db, targetTitle);
  stake = Number(stake);

  if (a.cash < stake) throw new Error("رصيد المهاجم لا يكفي.");

  const success = Math.random() < 0.3;

  if (success) {
    const stolen = Math.min(t.cash, Math.floor(stake * 0.5));
    t.cash -= stolen;
    a.cash += stolen;
    saveBank(db);
    return { success: true, stolen };
  } else {
    a.cash -= stake;
    saveBank(db);
    return { success: false, lost: stake };
  }
}

// Convert to USD
export function toUSD(amount, rate = 1000) {
  return Number(amount) / rate;
}

// Beautiful formatted output
export function formatPlayer(player) {
  return `
╭─✦ 𝗩𝗜𝗫 𝗕𝗔𝗡𝗞 ✦─╮
👑 اللقب: ${player.title}
💰 الرصيد: ${player.cash} 🪙
💎 الماس: ${player.diamonds}
🏦 البنك: ${player.bank}
📦 الأغراض: ${player.items.length ? player.items.join(", ") : "لا توجد"}
🕒 منذ: ${new Date(player.createdAt).toLocaleString()}
╰────────────────╯`;
}

export function formatBank(player) {
  return `
╭═══⟦ 💼 حساب بنكي – VIX BANK ⟧═══╮
│ 🔖 اللقب: ${player.title}
│ 💰 الكاش: ${player.cash} 🪙
│ 🏦 البنك: ${player.bank} 🏛️
│ 🕒 مُسجَّل منذ: ${new Date(player.createdAt).toLocaleString()}
╰════════════════════════════╯`;
}